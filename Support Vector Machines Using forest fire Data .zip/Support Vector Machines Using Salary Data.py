#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Importing libraries to play with data
import numpy as np
import pandas as pd


# In[2]:


# Importing the data itself
data_set  = pd.read_csv('C:\\Users\\Admin\\Downloads\\SalaryData_Test(1).csv')


# Now, let's see the data info

# In[3]:


data_set.info()


# In[4]:


data_set.head()


# In[5]:


# Let's see how many unique categories we have in this property
occupation_set = set(data_set['occupation'])
print(occupation_set)


# In[6]:


# Now we classify them as numers instead of their names.
data_set['occupation'] = data_set['occupation'].map({'?': 0, 'Farming-fishing': 1, 'Tech-support': 2, 
                                                       'Adm-clerical': 3, 'Handlers-cleaners': 4, 'Prof-specialty': 5,
                                                       'Machine-op-inspct': 6, 'Exec-managerial': 7, 
                                                       'Priv-house-serv': 8, 'Craft-repair': 9, 'Sales': 10, 
                                                       'Transport-moving': 11, 'Armed-Forces': 12, 'Other-service': 13, 
                                                       'Protective-serv': 14}).astype(int)


# In[7]:


# Just print it to see if nothing gone wrong
data_set.head()


# In[9]:


# Again, let's see how many unique categories we have in this property
income_set = set(data_set['income'])
print(income_set)


# In[10]:


# As expected. Just transforming now.
data_set['income'] = data_set['income'].map({'<=50K': 0, '>50K': 1}).astype(int)


# In[11]:


# Just print it to see if nothing gone wrong
data_set.head()


# In[12]:


# Importing matlab to plot graphs
import matplotlib as plt
get_ipython().run_line_magic('matplotlib', 'inline')


# In[13]:


data_set.groupby('education').income.mean().plot(kind='bar')


# In[14]:


data_set.groupby('occupation').income.mean().plot(kind='bar')


# ## Setting up a Support Vector Machine
# Before that, let's split our data into training and test set.

# In[15]:


from sklearn.model_selection import train_test_split

# Taking only the features that is important for now
X = data_set[['education.num', 'occupation']]

# Taking the labels (Income)
Y = data_set['income']

# Spliting into 80% for training set and 20% for testing set so we can see our accuracy
X_train, x_test, Y_train, y_test = train_test_split(X, Y, test_size=0.2, random_state=0)


# In[16]:


# Importing C-Support Vector Classification from scikit-learn
from sklearn.svm import SVC

# Declaring the SVC with no tunning
classifier = SVC()

# Fitting the data. This is where the SVM will learn
classifier.fit(X_train, Y_train)

# Predicting the result and giving the accuracy
score = classifier.score(x_test, y_test)

print(score)


# In[17]:


# Transforming the Sex into 0 and 1
data_set['sex'] = data_set['sex'].map({'Male': 0, 'Female': 1}).astype(int)


# In[18]:


# How many unique races we got here?
race_set = set(data_set['race'])
print(race_set)


# In[19]:


data_set['race'] = data_set['race'].map({'Black': 0, 'Asian-Pac-Islander': 1, 'Other': 2, 'White': 3, 
                                             'Amer-Indian-Eskimo': 4}).astype(int)


# In[20]:


# What about maritial status?
mstatus_set = set(data_set['marital.status'])
print(mstatus_set)


# In[21]:


data_set['marital.status'] = data_set['marital.status'].map({'Married-spouse-absent': 0, 'Widowed': 1, 
                                                             'Married-civ-spouse': 2, 'Separated': 3, 'Divorced': 4, 
                                                             'Never-married': 5, 'Married-AF-spouse': 6}).astype(int)


# In[22]:


# Everythin' good?
data_set.head()


# In[23]:


import seaborn as sns
import matplotlib.pyplot as pplt
#correlation matrix
corrmat = data_set.corr()
f, ax = pplt.subplots(figsize=(12, 9))
sns.heatmap(corrmat, vmax=.8, square=True);


# In[24]:


k = 8 #number of variables for heatmap
cols = corrmat.nlargest(k, 'income')['income'].index
cm = np.corrcoef(data_set[cols].values.T)
sns.set(font_scale=1.25)
hm = sns.heatmap(cm, cbar=True, annot=True, square=True, fmt='.2f', annot_kws={'size': 10}, yticklabels=cols.values, xticklabels=cols.values)
pplt.show()


# In[25]:


# Taking only the features that is important for now
X = data_set[['education.num', 'age']]

# Taking the labels (Income)
Y = data_set['income']

# Spliting into 80% for training set and 20% for testing set so we can see our accuracy
X_train, x_test, Y_train, y_test = train_test_split(X, Y, test_size=0.2, random_state=0)


# In[26]:


# Declaring the SVC with no tunning
classifier = SVC()

# Fitting the data. This is where the SVM will learn
classifier.fit(X_train, Y_train)

# Predicting the result and giving the accuracy
score = classifier.score(x_test, y_test)

print(score)


# In[27]:


# Taking only the features that is important for now
X = data_set[['education.num', 'age', 'hours.per.week', 'capital.gain']]

# Taking the labels (Income)
Y = data_set['income']

# Spliting into 80% for training set and 20% for testing set so we can see our accuracy
X_train, x_test, Y_train, y_test = train_test_split(X, Y, test_size=0.2, random_state=0)


# In[28]:


# Declaring the SVC with no tunning
classifier = SVC()

# Fitting the data. This is where the SVM will learn
classifier.fit(X_train, Y_train)

# Predicting the result and giving the accuracy
score = classifier.score(x_test, y_test)

print(score)


# In[29]:


data_set.groupby('race').income.mean().plot(kind='bar')


# In[30]:


data_set.groupby('sex').income.mean().plot(kind='bar')


# In[31]:


# Mean below 20 years old
data_set.groupby('age').income.mean().plot(kind='bar')


# In[ ]:




